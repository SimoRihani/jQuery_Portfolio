package tec;

public abstract class PassagerAbstrait implements Passager, Usager{
    
    private String nom;
    
    private int destination;

    private Comportement comportement;
    
    // si assis et debout valent false, le passager est dehors
    private boolean assis; // true si le passager est assis
    private boolean debout; //true si le passager est debout
	
    private EtatPassager etat;
	
	
    
    public PassagerAbstrait(String nom, int destination, Comportement comportement) {
	this.nom = nom;
	this.destination = destination;
	//		this.assis = false;
	//		this.debout = false;	
	etat = EtatPassager.construct();

	this.comportement = comportement;
    }
	
    public PassagerAbstrait(String nom, int destination) {
	this.nom = nom;
	this.destination = destination;
	this.assis = false;
	this.debout = false;
    }
    
    public String nom() {
	return this.nom;
    }
    
    public boolean estDehors() {
	return etat.estExterieur();
    }
    
    public boolean estAssis() {
	return etat.estAssis();
    }
    
    public boolean estDebout() {
	return etat.estDebout();
    }
    
    public void accepterSortie() {
	etat = etat.dehors();
    }
    
    public void accepterPlaceAssise() {
	etat = etat.assis();
    }
    
    public void accepterPlaceDebout() {
	etat = etat.debout();
    }
    
    public int timeToDest(int arretCourant) {
	return (this.destination - arretCourant);
    }

    abstract protected void choixPlaceMontee(Bus b);

    public final void monterDans(Transport t) throws TecInvalidException {
	Bus b; 
	try {	
	    b	= (Bus) t;
	} catch (java.lang.RuntimeException e) {
	    throw new TecInvalidException("t n'est pas un bus ");
	}
	choixPlaceMontee(b);
    }

    public final void nouvelArret(Bus b, int numeroArret) throws IllegalStateException{
	if (timeToDest(numeroArret) == 0) {
	    try {
		b.demanderSortie(this);
	    } catch (IllegalStateException e){
		throw new IllegalStateException();
	    }
	}
	try {
	    comportement.choixChangerPlace(b, numeroArret, this);
	} catch (IllegalStateException e){
	    throw new IllegalStateException();
	}
    }

    @Override
    public String toString() {
	return nom + " " + etat.toString();
    }
    
}
