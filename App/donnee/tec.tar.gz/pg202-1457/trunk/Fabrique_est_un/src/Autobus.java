package tec;
import java.util.ArrayList;
import java.util.Iterator;


public class Autobus implements Bus,Transport {
    private int arret;
    private JaugeNaturel jaugeAssis;
    private JaugeNaturel jaugeDebout;
    private ArrayList<Passager> passagers;
    /*
     * Instanciation
     */
    public Autobus(int assis, int debout) {
	jaugeAssis = new JaugeNaturel(assis, 0);
	jaugeDebout = new JaugeNaturel(debout, 0);
	passagers = new ArrayList<Passager>(assis+debout);
	arret = 0;
    }
    
    
    /*
     * Au moins une place assise est disponible
     */
    public boolean aPlaceAssise() {
	return jaugeAssis.estVert();
    }
    
    
    
    /*
     * Au moins une place debout est disponible
     */
    public boolean aPlaceDebout() {
	return jaugeDebout.estVert();
    }
    
    
    /*
     *Le passager est en dehors du bus et demande une place assise 
     */
    public void demanderPlaceAssise(Passager p) {
	if (aPlaceAssise()) {
	    passagers.add(p);
	    p.accepterPlaceAssise();
	    jaugeAssis.incrementer();
	}
    }
    
    
    /*
     *Le passager est en dehors du bus et demande une place debout 
     */
    
    public void demanderPlaceDebout(Passager p){
	if(aPlaceDebout()){
	    passagers.add(p);
	    p.accepterPlaceDebout();
	    jaugeDebout.incrementer();
	}
    }
    
    
    /*
     * Fait sortir un passager du bus (le passager doit etre dans le bus)
     */
    public void demanderSortie(Passager p) {
	if (p.estAssis()) 
	    jaugeAssis.decrementer();
	
	if (p.estDebout()) 
	    jaugeDebout.decrementer();
	
	p.accepterSortie();
	passagers.remove(p);
    }
    
    
    public void demanderChangerEnDebout(Passager p) {
	if (p.estAssis()) {
	    p.accepterPlaceDebout();
	    jaugeAssis.decrementer();
	    jaugeDebout.incrementer();
	}
    }
    
    
    public void demanderChangerEnAssis(Passager p) {
	if (p.estDebout()) {
	    p.accepterPlaceAssise();
	    jaugeDebout.decrementer();
	    jaugeAssis.incrementer();
	}
    }
    
    
    public void allerArretSuivant() throws TecInvalidException {
	int i = 0;
	arret++;
	ArrayList<Passager> passagersCopie = new ArrayList<Passager>(passagers);
	int compteur = passagers.size();
	for (i = 0 ; i < compteur; i++) {
	    try {
		passagersCopie.get(i).nouvelArret(this, arret);
	    } catch (java.lang.IllegalStateException e) {
		throw new TecInvalidException("la méthode allerArretSuivant a lancé une exception", e.getCause());
	    }
	}
    }
    
    @Override
    public String toString() {
	return "[arret:" + arret + ", assis:" + jaugeAssis.toString() + ", debout:" + jaugeDebout.toString() + "]";
    }
}

