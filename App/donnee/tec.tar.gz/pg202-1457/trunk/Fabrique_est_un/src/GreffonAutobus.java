package tec;

public class GreffonAutobus extends Autobus {
	private CollecteAbstraite collecte;

	public GreffonAutobus(int assis, int debout) {
		super(assis, debout);
	}

	public GreffonAutobus(int assis, int debout, CollecteAbstraite c) {
		super(assis, debout);
		collecte = c; 
	}

	/*
		*Le passager est en dehors du bus et demande une place assise 
		*/
	public void demanderPlaceAssise(Passager p) {
		if(aPlaceAssise()) {
			collecte.uneEntree();
		}
		super.demanderPlaceAssise(p);
	}


	/*
		*Le passager est en dehors du bus et demande une place debout 
		*/
	public void demanderPlaceDebout(Passager p){
		if(aPlaceDebout()) {
			collecte.uneEntree();
		}
		super.demanderPlaceDebout(p);
	}	
    
	/*
		* Fait sortir un passager du bus (le passager doit etre dans le bus)
		*/
	public void demanderSortie(Passager p) {
		collecte.uneSortie();
		super.demanderSortie(p);
	}

    
	public void allerArretSuivant() throws TecInvalidException{
		collecte.changerArret(collecte.numArret);
		super.allerArretSuivant();
	}
}
