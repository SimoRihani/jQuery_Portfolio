package tec;

public final class FabriqueTec {
    
    public static Usager fairePassagerStandard(String nom, int destination) {
	return new Repos(nom, destination, Calme.calme);
    }
    
    public static Usager fairePassagerStresse(String nom, int destination) {
	return new Fatigue(nom,destination, Prudent.prudent);
    }
    
    
    public static Usager fairePassagerLunatique(String nom, int destination) {
	return new Sportif(nom, destination, Nerveux.nerveux);
    }
    
    /*
      Constructeurs pour les différents transports
    */
    public static Transport faireAutobus(int assis, int debout) {
	return new Autobus(assis, debout);
    }
    
    /*
      Constructeurs pour les différents transports
    */
    public static Transport faireGreffonAutobus(int assis, int debout, CollecteAbstraite c) {
	return new GreffonAutobus(assis, debout, c);
    }
		
		public static CollecteMemoire faireCollecteMemoire(){
			return new CollecteMemoire();
		}
    
		public static CollecteFichier faireCollecteFichier() {
			return new CollecteFichier();
		}
}
