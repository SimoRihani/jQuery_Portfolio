package tec;

import java.util.Scanner;
import java.io.*;


class CollecteFichier extends CollecteAbstraite{
	File f;


	public CollecteFichier(){
		super();
		File tmp=new File("collecte.txt");
		tmp.delete();
		f=new File("collecte.txt");
	
	}
    
	protected void ajoutDonnee(int numero){
		try{
			FileWriter fw= new FileWriter(f,true);
			fw.append("A l'arret : " + String.valueOf(numero) + "\nSortie: " +String.valueOf(nb_sortie) + "\nEntrée: "  + String.valueOf(nb_entree) + "\n");
			fw.close();
		}
		catch(IOException exception){
			System.out.println("Erreur dans l'écriture " + exception.getMessage());
		}
	}

	public void afficher(){

		try{
			Scanner scan=new Scanner(f);
			System.out.println("\n== Affichage Collecte ==");
			System.out.println("Logs sauvegardés dans collecte.txt\n");
			while(scan.hasNextLine()){
				String l=scan.nextLine();
				System.out.println(l);
				l=scan.nextLine();
				System.out.println(l);
				l=scan.nextLine();
				System.out.println(l);
                
			}
			scan.close();
		}
		catch(FileNotFoundException exception){
			System.out.println("Erreur dans le fichier " + exception.getMessage());
		}
	}

}
		
	
