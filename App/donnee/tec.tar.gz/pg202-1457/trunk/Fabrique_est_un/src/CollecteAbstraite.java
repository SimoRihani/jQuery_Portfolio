package tec;

public abstract class CollecteAbstraite {
    protected int nb_entree;
    protected int nb_sortie;
		protected int numArret;

    public CollecteAbstraite(){
        nb_entree = 0;
        nb_sortie = 0;
    }
    public void uneEntree(){
        nb_entree++;
    }
    public void uneSortie(){
        nb_sortie++;
    }
    abstract protected void ajoutDonnee(int numero);
		
		abstract public void afficher();

    public void changerArret(int numero_arret){
			numArret++;
        ajoutDonnee(numero_arret);
        nb_entree = 0;
        nb_sortie = 0;
    }
}
