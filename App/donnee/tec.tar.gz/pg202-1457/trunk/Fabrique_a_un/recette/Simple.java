import tec.Transport;
import tec.Usager;
import tec.FabriqueTec;
import tec.CollecteAbstraite;

import tec.Autobus;
        

class Simple {

	/*
		* Affiche les etats d'un usager et d'un transport.
		* Sur un parametre de type Object, la methode println()
		* utilise la methode toString().
		* La methodes toString() doit etre redefinie dans les
		* deux classes PassagerStandard et Autobus.
		*/
	static private void deboguerEtat (Transport t, Usager p) {
		System.out.println(p);
		System.out.println(t);
	}

	static public void main (String[] args)  throws tec.TecInvalidException{
                
		CollecteAbstraite collecte = FabriqueTec.faireCollecteMemoire();
		Transport serenity = FabriqueTec.faireAutobus(5, 5, collecte);
		
		System.out.println("\n");
		Usager test = FabriqueTec.fairePassagerStandard("test",3);
		test.monterDans(serenity);
		serenity.allerArretSuivant(); 
		System.out.println(serenity); // Arret 1

		Usager kaylee = FabriqueTec.fairePassagerStandard("Kaylee", 5);
		kaylee.monterDans(serenity); // Kaylee Monte
                
		Usager paul = FabriqueTec.fairePassagerStandard("paulo", 7);
		paul.monterDans(serenity); // Paul Monte

		Usager jayne = FabriqueTec.fairePassagerStandard("Jayne", 4);
		jayne.monterDans(serenity); // Jayne monte 
                
		System.out.println("\n");
		serenity.allerArretSuivant(); // Arret 2 + 3 personnes (Pual Kaylee Jayne)
		// debogue
		System.out.println(serenity);
		System.out.println(kaylee);
		System.out.println(jayne);
		System.out.println(paul);
		System.out.println("\n");

		Usager inara = FabriqueTec.fairePassagerStandard("Inara", 5);
		inara.monterDans(serenity);
        
		serenity.allerArretSuivant(); // Arret 3 + 1 personne 
		// debogue
		System.out.println(serenity);
		System.out.println(kaylee);
		System.out.println(jayne);
		System.out.println(inara);
		System.out.println(paul);
		System.out.println("\n");


		serenity.allerArretSuivant();
		// debogue
		System.out.println(serenity);
		System.out.println(kaylee);
		System.out.println(jayne);
		System.out.println(inara);
		System.out.println(paul);
		System.out.println("\n");
                

		serenity.allerArretSuivant(); // kaylee inara sortent au 5 
		// debogue
		System.out.println(serenity);
		System.out.println(kaylee);
		System.out.println(jayne);
		System.out.println(inara);
		System.out.println(paul);
		System.out.println("\n");
                
		serenity.allerArretSuivant(); // kaylee inara sortent au 5 
		// debogue
		System.out.println(serenity);
		System.out.println(kaylee);
		System.out.println(jayne);
		System.out.println(inara);
		System.out.println(paul);
		System.out.println("\n");
                
		serenity.allerArretSuivant(); // kaylee inara sortent au 5 
		// debogue
		System.out.println(serenity);
		System.out.println(kaylee);
		System.out.println(jayne);
		System.out.println(inara);
		System.out.println(paul);
		System.out.println("\n");
                
		serenity.allerArretSuivant(); // kaylee inara sortent au 5 
		// debogue
		System.out.println(serenity);
		System.out.println(kaylee);
		System.out.println(jayne);
		System.out.println(inara);
		System.out.println(paul);
                
		collecte.afficher();
	}
}

/* Resultat de l'execution.
[arret:1, assis:0, debout:0]
[arret:2, assis:1, debout:1]
Kaylee assis
Jayne debout
[arret:3, assis:1, debout:2]
Kaylee assis
Jayne debout
Inara debout
[arret:4, assis:1, debout:1]
Kaylee assis
Jayne dehors
Inara debout
[arret:5, assis:0, debout:0]
Kaylee dehors
Jayne dehors
Inara dehors
*/