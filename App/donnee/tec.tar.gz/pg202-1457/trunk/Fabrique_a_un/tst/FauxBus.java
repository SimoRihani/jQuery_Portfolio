package tec;

public class FauxBus implements Bus, Transport{
    public Messages msg;
    public FauxBus(int assis, int debout) {
	msg = new Messages();
	msg.clear ();
    }
    
    public boolean aPlaceAssise() {
	msg.add("aPlaceAssise");
	return false;
    }

    public boolean aPlaceDebout() {
	msg.add("aPlaceDebout");
	return true;
    }

    public void demanderPlaceAssise(Passager p) {
	msg.add ("demanderPlaceAssise");
    }

    public void demanderPlaceDebout(Passager p) {
	msg.add ("demanderPlaceDebout");
    }

    public void demanderSortie(Passager p) {
    }

    public void demanderChangerEnDebout(Passager p) {
    }

    public void demanderChangerEnAssis(Passager p) {
    }

    public void allerArretSuivant() { 
    }
}
