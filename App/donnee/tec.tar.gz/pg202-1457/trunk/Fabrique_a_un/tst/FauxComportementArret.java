package tec;

class FauxComportementArret implements Comportement {

    public Messages msg;

    public void choixChangerPlace(Bus b, int arret, Passager p) {
	msg.add("choixChangerPlace");
    }
}
