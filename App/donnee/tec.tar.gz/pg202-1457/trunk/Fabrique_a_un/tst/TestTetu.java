package tec;

class TestTetu extends TestPassagerAbstrait {

    protected PassagerAbstrait creerPassager(String nom, int destination, Comportement comp) {
      	return (PassagerAbstrait) new Tetu(nom,destination, comp);
    }  
    
    void testChoixPlaceMontée() {
	Autobus b1 = new Autobus(0, 0);
	PassagerAbstrait p1 = creerPassager("p1", 0, new FauxComportementArret());
	p1.choixPlaceMontee(b1);
	assert p1.estDehors() == true : "aucune place debout libre dans b1, p1 a essayé mais reste dehors";
	
	Autobus b2 = new Autobus(0, 1);
	PassagerAbstrait p2 = creerPassager("p2", 0, new FauxComportementArret());
	p2.choixPlaceMontee(b2);
	assert p2.estDebout() == true : "il y a une place debout dans b2, p2 rentre";
    }
    
    void testCodeConstant() {
	int nbTest = 0;
	
	nbTest++;
	testAccepterSortie();
	nbTest++;
	testAccepterPlaceDebout();
	nbTest++;
	testAccepterPlaceAssise();
	nbTest++;
	testAccesseurs();
    }
}