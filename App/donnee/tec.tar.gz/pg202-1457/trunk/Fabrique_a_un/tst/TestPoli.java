package tec;

class TestPoli extends TestPassagerAbstrait {

    protected PassagerAbstrait creerPassager(String nom, int destination, Comportement comp) {
	return (PassagerAbstrait) new FauxComportementMontee(nom,destination,comp);
    }

    void testChoixChangerPlace() {
	Autobus b1 = new Autobus(1,1);
	Comportement c1 = Poli.poli;
	PassagerAbstrait p1 = creerPassager("p2", 1, c1);
	b1.demanderPlaceAssise(p1);
	c1.choixChangerPlace(b1,0,p1);
	assert p1.estDebout() == true : "plus de place assise dans b1, c1 passe debout";
    
	Autobus b2 = new Autobus(2,1);
	Comportement c2 = Poli.poli;
	PassagerAbstrait p2 = creerPassager("p2", 1, c2);
	b2.demanderPlaceAssise(p2);
	c2.choixChangerPlace(b2,0,p2);
	assert p2.estAssis() == true : "il reste des places assises dans b2, c2 ne bouge pas";
    
	Autobus b3 = new Autobus(1,2);
	Comportement c3 = Poli.poli;
	PassagerAbstrait p31 = creerPassager("p31", 1, c3);
	PassagerAbstrait p32 = creerPassager("p32", 1, c3);
	b3.demanderPlaceDebout(p31);
	b3.demanderPlaceDebout(p32);
	c3.choixChangerPlace(b3,0,p31);
	assert p31.estDebout() == true : "p31 reste debout, même si il n'y a plus de place debout dans b3";
    }

    void testCodeConstant() {
	int nbTest = 0;
	
	nbTest++;
	testAccepterSortie();
	nbTest++;
	testAccepterPlaceDebout();
	nbTest++;
	testAccepterPlaceAssise();
	nbTest++;
	testAccesseurs();
    }
}