package tec;

class TestRepos extends TestPassagerAbstrait {

    protected PassagerAbstrait creerPassager(String nom, int destination, Comportement comp) {
      	return (PassagerAbstrait) new Repos(nom,destination, comp);
    }  
    
    void testChoixPlaceMontée() {
	Autobus b1 = new Autobus(1, 1);
	PassagerAbstrait p1 = creerPassager("p1", 0, new FauxComportementArret());
	p1.choixPlaceMontee(b1);
	assert p1.estAssis() == true : "une place assise et debout dans b1, p1 doit choisir la place assise";
	
	Autobus b2 = new Autobus(0, 1);
	PassagerAbstrait p2 = creerPassager("p2", 0, new FauxComportementArret());
	p2.choixPlaceMontee(b2);
	assert p2.estDebout() == true : "aucune place assise mais une place debout libre dans b2, p2 doit être debout";
    }
    
    void testCodeConstant() {
	int nbTest = 0;
	
	nbTest++;
	testAccepterSortie();
	nbTest++;
	testAccepterPlaceDebout();
	nbTest++;
	testAccepterPlaceAssise();
	nbTest++;
	testAccesseurs();
    }
}