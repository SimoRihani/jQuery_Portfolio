package tec;

class TestAgoraphobe extends TestPassagerAbstrait {

    protected PassagerAbstrait creerPassager(String nom, int destination, Comportement comp) {
	return (PassagerAbstrait) new FauxComportementMontee(nom,destination,comp);
    }

    void testChoixChangerPlace() {
	Autobus b1 = new Autobus(1,0);
	Comportement c1 = Agoraphobe.agoraphobe;
	PassagerAbstrait p1 = creerPassager("p1", 5, c1);
	b1.demanderPlaceAssise(p1);
	c1.choixChangerPlace(b1,0,p1);
	assert p1.estDehors() == true : "b1 est plein, p1 sort";
    
	Autobus b2 = new Autobus(0,1);
	Comportement c2 = Agoraphobe.agoraphobe;
	PassagerAbstrait p2 = creerPassager("p2", 5, c2);
	b2.demanderPlaceDebout(p2);
	c2.choixChangerPlace(b2,0,p2);
	assert p2.estDehors() == true : "b2 est plein, p2 sort";

	Autobus b3 = new Autobus(1,1);
	Comportement c3 = Agoraphobe.agoraphobe;
	PassagerAbstrait p3 = creerPassager("p3", 5, c3);
	b3.demanderPlaceAssise(p3);
	c3.choixChangerPlace(b3,0,p3);
	assert p3.estAssis() == true : "b3 a encore des places (debout en l'occurrence), p3 reste assis";
    }

    void testCodeConstant() {
	int nbTest = 0;
	
	nbTest++;
	testAccepterSortie();
	nbTest++;
	testAccepterPlaceDebout();
	nbTest++;
	testAccepterPlaceAssise();
	nbTest++;
	testAccesseurs();
    }
}