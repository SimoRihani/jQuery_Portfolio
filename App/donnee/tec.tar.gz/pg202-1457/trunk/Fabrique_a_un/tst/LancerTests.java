package tec;

public class LancerTests {
	public static void main(String... args) {
		boolean estMisAssertion = false;
		assert estMisAssertion = true;

		if (!estMisAssertion) {
			System.out.println("Execution impossible sans l'option -ea");
			return;
		}
	
		try{
		    /*
		     * Tests des comportements à la montée dans le bus
		     */
		    lancer(TestFatigue.class);
		    lancer(TestTetu.class);
		    lancer(TestRepos.class);
		    lancer(TestSportif.class);

		    /*
		     * Tests des comportements à un nouvel arrêt
		     */
		    lancer(TestCalme.class);
		    lancer(TestNerveux.class);
		    lancer(TestPrudent.class);
		    lancer(TestAgoraphobe.class);
		    lancer(TestPoli.class);


		    lancer(TestEtatPassager.class);
		    lancer(TestJaugeNaturel.class);
		    lancer(TestAutobus.class);
		}
		catch (Exception e){
			System.out.println("Erreur lors des tests : ");
			e.printStackTrace();
		}
	}
	
	static private void lancer(Class c) throws Exception{
		Object o = c.newInstance();
		java.lang.reflect.Method[] mesMethodes = c.getDeclaredMethods();
		int nbTest = 0;
		for (int i = 0; i < mesMethodes.length; i++) {
			java.lang.reflect.Method m = mesMethodes[i];
			if (m.getName().startsWith("test")){
				System.out.print(".");
				m.invoke(o);
				nbTest++;
			}
		}
		System.out.println("(" + nbTest + "):OK: " + o.getClass().getName());
	}
}
