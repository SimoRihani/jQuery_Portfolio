package tec;

class TestSportif extends TestPassagerAbstrait {

    protected PassagerAbstrait creerPassager(String nom, int destination, Comportement comp) {
      	return (PassagerAbstrait) new Sportif(nom,destination, comp);
    }  
    
    void testChoixPlaceMontée() {
	Autobus b1 = new Autobus(1, 0);
	PassagerAbstrait p1 = creerPassager("p1", 0, new FauxComportementArret());
	p1.choixPlaceMontee(b1);
	assert p1.estDehors() == true : "aucune place debout dans b1, p1 doit être resté dehors";
	
	Autobus b2 = new Autobus(1, 1);
	PassagerAbstrait p2 = creerPassager("p2", 0, new FauxComportementArret());
	p2.choixPlaceMontee(b2);
	assert p2.estDebout() == true : "une place debout dans b2, p2 doit être debout";
    }
    
    void testCodeConstant() {
	int nbTest = 0;
	
	nbTest++;
	testAccepterSortie();
	nbTest++;
	testAccepterPlaceDebout();
	nbTest++;
	testAccepterPlaceAssise();
	nbTest++;
	testAccesseurs();
    }
}