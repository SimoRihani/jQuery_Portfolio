package tec;

abstract class TestPassagerAbstrait {

	abstract protected PassagerAbstrait creerPassager(String nom, int destination, Comportement comp);

	void testAccepterSortie() {
		PassagerAbstrait p = creerPassager("p", 0, new FauxComportementArret());
		p.accepterSortie();
		assert p.estDehors() == true : "le passager doit être sorti";
		assert p.estAssis() == false : "un passager dehors n'est pas assis";
		assert p.estDebout() == false : "un passager dehors n'est pas debout";
	}

	void testAccepterPlaceDebout() {
		PassagerAbstrait p = creerPassager("p", 0,new FauxComportementArret());
		p.accepterPlaceDebout();
		assert p.estDehors() == false : "le passager doit être dans un bus";
		assert p.estAssis() == false : "le passager doit être debout";
		assert p.estDebout() == true : "le passager doit être debout";
	}

	void testAccesseurs() {
		PassagerAbstrait p = creerPassager("p", 0, new FauxComportementArret());
		assert p.nom() == "p" : "le nom doit être celui donné au constructeur";
		assert p.estDehors() == true : "par défaut un passager est dehors";
		assert p.estAssis() == false : "par défaut un passager est dehors";
		assert p.estDebout() == false : "par défaut un passager est dehors";

	}

	void testAccepterPlaceAssise() {
		PassagerAbstrait p = creerPassager("p", 0, new FauxComportementArret());
		p.accepterPlaceAssise();
		assert p.estDehors() == false : "le passager doit être dans un bus";
		assert p.estAssis() == true : "le passager doit être assis";
		assert p.estDebout() == false : "le passager doit être assis";
	}
		
		
	void testExceptionMonterDans() {
		Transport t = new Transport() {
			public void allerArretSuivant(){}
				public boolean aPlaceAssise() {
					return false;
				}
				public boolean aPlaceDebout() {
					return true; 
				}
			};
				
			PassagerAbstrait p = creerPassager("p",0, Poli.poli);
			try {
				p.monterDans(t);
				assert false : "echec du test, exception non levée";
			} catch (TecInvalidException e) {
				assert true : "exception levée";
			}
		
	}
}