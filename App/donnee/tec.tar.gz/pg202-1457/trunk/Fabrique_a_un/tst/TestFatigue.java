package tec;

class TestFatigue extends TestPassagerAbstrait {

    protected PassagerAbstrait creerPassager(String nom, int destination, Comportement comp) {
      	return (PassagerAbstrait) new Fatigue(nom,destination, comp);
    }  
    
    void testChoixPlaceMontée() {
	Autobus b1 = new Autobus(1, 0);
	PassagerAbstrait p1 = creerPassager("p1", 0, new FauxComportementArret());
	p1.choixPlaceMontee(b1);
	assert p1.estAssis() == true : "une place assise était libre dans b1, p1 doit être assis";
	
	Autobus b2 = new Autobus(0, 1);
	PassagerAbstrait p2 = creerPassager("p2", 0, new FauxComportementArret());
	p2.choixPlaceMontee(b2);
	assert p2.estDehors() == true : "aucune place assise n'était libre dans b2, p2 doit être resté dehors";
    }
    
    void testCodeConstant() {
	int nbTest = 0;
	
	nbTest++;
	testAccepterSortie();
	nbTest++;
	testAccepterPlaceDebout();
	nbTest++;
	testAccepterPlaceAssise();
	nbTest++;
	testAccesseurs();
    }
}