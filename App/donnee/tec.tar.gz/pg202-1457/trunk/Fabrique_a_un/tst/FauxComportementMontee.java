package tec;

class FauxComportementMontee extends PassagerAbstrait {
    Messages msg = new Messages();

    public FauxComportementMontee(String nom, int destination, Comportement comp) {
	super(nom, destination, comp);
    }

    protected void choixPlaceMontee(Bus b) {
	msg.add("choixplaceMontee");
    }
}