package tec;

public interface Usager {
  public String nom();

  public void monterDans(Transport t) throws TecInvalidException;
}
