package tec;

class Fatigue extends PassagerAbstrait {

    public Fatigue(String nom, int destination, Comportement comp) {
	super(nom, destination, comp);
    }

/*
 * Prend une place assise ou rien
 */
    protected void choixPlaceMontee(Bus b) {
	Transport t = (Transport) b;
	if (t.aPlaceAssise())
	    b.demanderPlaceAssise(this);
    }
}