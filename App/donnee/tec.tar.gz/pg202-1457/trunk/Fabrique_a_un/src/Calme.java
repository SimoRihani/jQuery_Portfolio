package tec;

class Calme implements Comportement {
	static Calme calme = new Calme();
/*
 * Ne bouge pas
 */
    public void choixChangerPlace(Bus b, int arret, Passager p) {
	PassagerAbstrait pa = (PassagerAbstrait) p;
    }
		
		private Calme() {};
}