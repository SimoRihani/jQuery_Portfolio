package tec;

interface Comportement {
    void choixChangerPlace(Bus b, int arret, Passager p);
}