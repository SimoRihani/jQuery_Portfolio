package tec;

import java.util.ArrayList;

class CollecteMemoire extends CollecteAbstraite{
    ArrayList collecte;

    public CollecteMemoire(){
        super();
        collecte = new ArrayList();
    }

    protected void ajoutDonnee(int numero){
        collecte.add(numero);
        collecte.add(nb_entree);
        collecte.add(nb_sortie);
    }

    public void afficher(){
                        System.out.println("\n== Affichage Collecte ==");
        for (int i = 0; i<collecte.size(); i= i+3){
            System.out.println("A l'arret " +collecte.get(i) + " : " + collecte.get(i+1) + " personne(s) entrée(s) et " + collecte.get(i+2) + " personne(s) sortie(s).");
        }
    }
}