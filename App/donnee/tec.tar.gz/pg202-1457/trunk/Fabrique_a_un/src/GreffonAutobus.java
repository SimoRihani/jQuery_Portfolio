package tec;

class GreffonAutobus implements Transport, Bus {
	private CollecteAbstraite collecte;
	private Autobus bus;

	public GreffonAutobus(int assis, int debout, CollecteAbstraite col){
		bus = new Autobus(assis,debout,this);
		collecte = col;
	}
       
	public boolean aPlaceAssise(){
		return bus.aPlaceAssise();
	}

	public boolean aPlaceDebout(){
		return bus.aPlaceDebout();
	}
    
	public void demanderPlaceAssise(Passager p){
		if(aPlaceAssise())
			collecte.uneEntree();
		bus.demanderPlaceAssise(p);
	}

	public void demanderPlaceDebout(Passager p){
		if(aPlaceDebout())
			collecte.uneEntree();
		bus.demanderPlaceDebout(p);
	}
    
	public void demanderSortie(Passager p){
		bus.demanderSortie(p);
		collecte.uneSortie();
	}

	public void demanderChangerEnDebout(Passager p){
		bus.demanderChangerEnDebout(p);
	}

	public void demanderChangerEnAssis(Passager p){
		bus.demanderChangerEnAssis(p);
	}


	public void allerArretSuivant() throws TecInvalidException{
		bus.allerArretSuivant();
		collecte.changerArret(collecte.numArret+1);
	}
	
	public String toString(){
		return bus.toString();
	}
}
