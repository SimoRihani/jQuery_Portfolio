package tec;

class Sportif extends PassagerAbstrait {

    public Sportif(String nom, int destination, Comportement comp) {
	super(nom, destination, comp);
    }

/*
 * Prend une place debout ou ne rentre pas
 */
    protected void choixPlaceMontee(Bus b) {
	Transport t = (Transport) b;
	if (t.aPlaceDebout())
	    b.demanderPlaceDebout(this);
    }
}