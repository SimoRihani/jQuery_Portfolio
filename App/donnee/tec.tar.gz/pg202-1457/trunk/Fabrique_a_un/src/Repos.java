package tec;

class Repos extends PassagerAbstrait {

    public Repos(String nom, int destination, Comportement comp) {
	super(nom, destination, comp);
    }

/*
 * Préfère une place assise, sinon prend une place debout
 */
    protected void choixPlaceMontee(Bus b) {
	Transport t = (Transport) b;
	if (t.aPlaceAssise())
	    b.demanderPlaceAssise(this);
	else 
	    b.demanderPlaceDebout(this);
    }
}