package tec;

public interface Transport {
  public boolean aPlaceAssise();
  public boolean aPlaceDebout();
  public void allerArretSuivant() throws TecInvalidException;
}
