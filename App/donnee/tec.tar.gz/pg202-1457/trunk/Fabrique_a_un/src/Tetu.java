package tec;

class Tetu extends PassagerAbstrait {

    public Tetu(String nom, int destination, Comportement comp) {
	super(nom, destination, comp);
    }

/*
 * Prend une place debout même si le bus est plein 
 * (mais l'implémentation de Autobus.java fait que le passager ne pourra quand même pas rentrer)
 */
    protected void choixPlaceMontee(Bus b) {
	b.demanderPlaceDebout(this);
    }
}