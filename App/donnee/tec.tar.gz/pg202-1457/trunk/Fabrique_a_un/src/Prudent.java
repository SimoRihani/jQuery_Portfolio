package tec;

class Prudent implements Comportement {

/*
 * Choisit une place assise si il est à plus de 5 arrêts de sa destination 
 * et une place debout si il est à moins de 3 arrêts de sa destination
 */
	
	static Prudent prudent = new Prudent();
	
    public void choixChangerPlace(Bus b, int arret, Passager p) {
	PassagerAbstrait pa = (PassagerAbstrait) p;
	int d = pa.timeToDest(arret);
	if (d < 3)
	    b.demanderPlaceDebout(p);
	else if (d > 5)
	    b.demanderPlaceAssise(p);
    }
		
		private Prudent() {};
}