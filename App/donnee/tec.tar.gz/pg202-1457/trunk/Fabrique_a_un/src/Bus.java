package tec;

interface Bus {

  public void demanderPlaceAssise(Passager p);
  public void demanderPlaceDebout(Passager p);
  public void demanderSortie(Passager p);

  public void demanderChangerEnDebout(Passager p);
  public void demanderChangerEnAssis(Passager p);

}
