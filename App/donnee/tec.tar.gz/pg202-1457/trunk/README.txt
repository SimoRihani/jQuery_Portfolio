Ce répertoire de code constitue le livrable du projet de PG202.

On y trouve les sous-répertoires Fabrique_est_un et Fabrique_a_un.

À l'implémentation près, les deux répertoires sont identiques et contiennent tout deux un Makefile avec quatre commandes principales :
    make         compile les sources et lance le scénario de recette/Simple.java
    make build 	 compile les sources
    make tests   compile et lance tous les tests (y compris les tests de recette)
    make clean   vide les build

Si dans le fichier Simple.java il y'a la ligne présente à la fin c.afficher() ou bien collecte.afficher() alors les données seront aussi affichées à la fin de l'exécution de la recette.
Dans le cas de la collecte Mémoire c'est le seul moyen de voir la collecte, dans le cas de la collecte Fichier, un fichier collecte.txt est généré : il résume l'execution de la recette.

Si le client souhaite modifier la méthode de collecte il lui suffit simplement de changer dans Simple.java le constructeur en par exemple "faireCollecteFichier()" ou 'faireCollecteMemoire()". Sinon, il suffit de déclarer un Autobus avec le constructeur sans Collecte "faireAutobus(assis,debout)".

