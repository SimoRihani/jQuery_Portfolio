Ce dépôt contient l'ensemble du code des huit séances de PG202.Il présente quatre répertoires.

trunk	  contient le code constituant le livrable final du projet
tags 	  contient les livrables des différents TD et donc représente un historique du trunk
branches  était le repertoire de travail pendant les séances, il est désormais inutile
cr 	  contient les compte-rendus des différents TD

Dans le trunk, on peut trouver un README expliquant de quelle façon compiler le code ainsi que des indications sur le fonctionnement du système de greffon.


