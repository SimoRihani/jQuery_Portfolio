package tec;

class TestPassagerStresse extends TestPassagerAbstrait {

    protected PassagerAbstrait creerPassager(String nom, int destination) {
	PassagerStresse p = new PassagerStresse(nom, destination);
	return p;
    }  

	void testChoixPlaceMontee() {
		PassagerStresse p1 = new PassagerStresse("p", 1);
		Autobus busDebout = new Autobus(0,1);
		p1.choixPlaceMontee(busDebout);
		assert p1.estDebout() == false :"Il ne rentre que si il y'a des places assises";
		assert p1.estAssis() == false :"Il ne rentre que si il y'a des places assises";
		assert p1.estDehors() == true :"Il ne rentre que si il y'a des places assises";

		PassagerStresse p2 = new PassagerStresse("p",1);
		Autobus busAssis = new Autobus(1,0);
		p2.choixPlaceMontee(busAssis);
		assert p2.estDebout() == false : "Il rentre vu qu'il y'a une place assise";
		assert p2.estAssis() == true :"Il rentre vu qu'il y'a une place assise";
		assert p2.estDehors() == false :"Il rentre vu qu'il y'a une place assise";
	}

	void testChoixChangerPlace() {
		PassagerStresse p1 = new PassagerStresse("p",4);
		Autobus bus = new Autobus(1,1);
	
		p1.monterDans(bus);
		assert p1.timeToDest(0) == 4:"Le passager est à 4 arrêts de son arrivée";
		assert p1.estAssis() == true : "Il ne rentre que si il y'a une place assise";
		assert p1.estDebout() == false : "Il ne rentre que si il y'a une place assise";

		bus.allerArretSuivant();
		assert p1.timeToDest(1) == 3 :"Le passager est à 3 arrêts de son arrivée";
	
		p1.choixChangerPlace(bus,1);
	       	assert p1.estAssis() == false :"Il est à au moins 3 arrêts de sa destination il se lève";
		assert p1.estDebout() == true : "Il est à au moins 3 arrêts de sa destination il se lève";
		assert p1.estDehors() == false :"Il n'est pas encore arrivé";

		bus.allerArretSuivant();
		bus.allerArretSuivant();
		bus.allerArretSuivant();
		p1.choixChangerPlace(bus,4);

		assert p1.estAssis() == false : "Il est arrivé";
		assert p1.estDebout() == false : "Il est arrivé";
		assert p1.estDehors() == true : "Il est arrivé";
	}	

	void lancer() {
		int nbTest = 0;

		System.out.println('.'); nbTest++;
		testChoixPlaceMontee();
		System.out.println('.'); nbTest++;
		testChoixChangerPlace();
		System.out.println("(" + nbTest + "):OK: " + getClass().getName());

	}
}
