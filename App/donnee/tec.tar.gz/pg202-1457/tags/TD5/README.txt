Ce repertoire contient l'ensemble du code implémenté pendant le troisième TD de PG2020.

On y trouve les sous-répertoires Publique et NonPublique, découlant des différentes implémentations des classes concrètes des différents Passagers et Bus (voir TD4).

À ce détail près, les deux répertoires sont idéntiques et contiennent tout deux un Makefile avec trois commandes principales :
    make  	 compile les sources et lance le scnénario de recette/Simple.java
    make tests	 compile et lance les tests
    make clean   vide les build

L'arborescence globale de ce TD est la suivante :

├── NonPublique
│   ├── Makefile
│   ├── build
│   ├── build-tst
│   ├── recette
│   ├── src
│   └── tst
├── Publique
│   ├── Makefile
│   ├── build
│   ├── build-tst
│   ├── recette
│   ├── src
│   └── tst
