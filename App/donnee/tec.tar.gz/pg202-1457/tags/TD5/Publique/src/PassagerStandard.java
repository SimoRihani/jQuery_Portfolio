package tec;

public class PassagerStandard extends PassagerAbstrait {

    public PassagerStandard(String nom, int destination) {
	super(nom, destination);
    }
    
    public void choixChangerPlace(Bus b, int arret) {
    }
    
    public void choixPlaceMontee(Bus b) { 
	if (b.aPlaceAssise())
	    b.demanderPlaceAssise(this);
	else if (b.aPlaceDebout())
	    b.demanderPlaceDebout(this);
    }
    
}