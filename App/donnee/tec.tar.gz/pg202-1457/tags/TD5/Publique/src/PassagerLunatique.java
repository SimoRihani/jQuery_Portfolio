package tec;

public class PassagerLunatique extends PassagerAbstrait {

    public PassagerLunatique(String nom, int destination) {
	super(nom, destination);
    }
    
    public void choixChangerPlace(Bus b, int arret) {
	if (estAssis())
	    b.demanderChangerEnDebout(this);
	else
	    b.demanderChangerEnAssis(this);
    }
    
    public void choixPlaceMontee(Bus b) { 
	if (b.aPlaceDebout())
	    b.demanderPlaceDebout(this);
    }
    
}