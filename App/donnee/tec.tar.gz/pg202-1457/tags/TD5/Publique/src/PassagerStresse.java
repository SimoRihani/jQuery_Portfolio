package tec;

public class PassagerStresse extends PassagerAbstrait {

    public PassagerStresse(String nom, int destination) {
	super(nom, destination);
    }
    
    public void choixChangerPlace(Bus b, int arret) {
	if(this.timeToDest(arret) < 4 && b.aPlaceDebout())
	    b.demanderPlaceDebout(this);
    }
    
    public void choixPlaceMontee(Bus b) { 
	if (b.aPlaceAssise())
	    b.demanderPlaceAssise(this);
    }
    
}