Ce repertoire contient l'ensemble du code implémenté pendant le second TD de PG2020.

On y trouve un sous-répertoire Tests contenant lui même plusieurs fichiers :

src  	      contient les sources correspondant aux deux premières parties du TD
build	      est a priori vide, il contient les binaires après compilation

Un Makefile cimple a aussi été implémenté, doté de trois commandes :
   make	    	  lance la compilation des fichiers de src vers le repertoire build et les execute
   make clean	  vide le repertoire build
   make mrproper  lance make clean et enlève en plus les fichiers parasites



Relativement à la troisième partie du TD, un autre repertoire JaugeNaturelAvecMethodeDacces a été crée, doté du même contenu que son repertoire parent, sans les fichiers affiliés à EtatPassager.

L'arborescence globale de ce TD est la suivante :

├—— JaugeNaturelAvecMethodeDacces
│   ├── Makefile
│   ├── build
│   └── src
│       ├── JaugeNaturel.java
│       ├── LancerTests.java
│       └── TestJaugeNaturel.java
├── Makefile
├── build
└── src
    ├── EtatPassager.java
    ├── JaugeNaturel.java
    ├── LancerTests.java
    ├── TestEtatPassager.java
    └── TestJaugeNaturel.java
