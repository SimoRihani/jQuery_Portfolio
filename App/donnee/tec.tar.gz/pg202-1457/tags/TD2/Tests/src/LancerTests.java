package tec;

public class LancerTests {
    public static void main(String... args) {
	boolean estMisAssertion = false;
	assert estMisAssertion = true;

	if (!estMisAssertion) {
	    System.out.println("Execution impossible sans l'option -ea");
	    return;
	}

	// comment lancer les tests ?
	System.out.println("Début des tests de EtatPassager");	
	TestEtatPassager t1 = new TestEtatPassager();
	t1.lancerTests();

	System.out.println("Début des tests de JaugeNaturel");
	TestJaugeNaturel t2 = new TestJaugeNaturel();
	t2.lancerTests(); 

    }
}