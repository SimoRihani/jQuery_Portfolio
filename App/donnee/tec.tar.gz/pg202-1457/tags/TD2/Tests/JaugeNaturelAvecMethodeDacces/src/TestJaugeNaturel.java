package tec;
import java.math.BigDecimal;

class TestJaugeNaturel {
       
    int compteur = 0;
    
    void testConstructeur () {
	JaugeNaturel j = new JaugeNaturel (10, -1);
	assert (j.valeur() == new BigDecimal(-1)) : "Le constructeur n'initialise pas correctement la valeur de départ";
	compteur++;
    }
	
    void testDeplacementValeur (){
	JaugeNaturel j = new JaugeNaturel (7, 70);
	j.incrementer ();
	assert (j.valeur () == new BigDecimal(71)) : "Methode incrementer() incoreccte";
	compteur++;
	j = new JaugeNaturel (7, 70);
	j.decrementer ();
	assert (j.valeur () == new BigDecimal(69)) : "Methode decrementer() incoreccte";
	compteur++;
    }
    void testDansIntervalle () {
		
	//Le parametre de depart dans l'intervalle [0,vigieMax[
	JaugeNaturel j = new JaugeNaturel (67899, 100);
	assert (j.estVert () == true) : "La valeur n'est pas dans l'intervalle";
	compteur++;
	
	//Le parametre de depart est egal a vigieMax
	j = new JaugeNaturel (68000, 68000);
	assert (j.estVert () == false) : "La valeur est dans l'intervalle";
	compteur++;
	
	//Le parametre de depart est superieur a vigieMax
	j = new JaugeNaturel (67899, 68000);
	assert (j.estVert () == false) : "La valeur est dans l'intervalle";
	compteur++;	

	//Le parametre de depart est nul et vigieMax > 0
	j = new JaugeNaturel (67899, 0); 
	assert (j.estVert () == true) : "La valeur n'est pas dans l'intervalle";
	compteur++;

	//Le parametre de depart et vigieMax sont nuls (cas particulier)
	j = new JaugeNaturel (0, 0); 
	assert (j.estVert () == false) : "La valeur de depart est dans l'intervalle";
	compteur++;

	//Le parametre de depart est negatif
	j = new JaugeNaturel (67899, -1);
	assert (j.estVert () == false) : "La valeur est dans l'intervalle";
	compteur++;	

    }



    void testSuperieur () {
		
	//Le parametre de depart dans l'intervalle [0,vigieMax[
	JaugeNaturel j = new JaugeNaturel (67899, 100);
	assert (j.estRouge () == false) : "La valeur est superieur a vigieMax";
	compteur++;
	
	//Le parametre de depart est egal a vigieMax
	j = new JaugeNaturel (68000, 68000);
	assert (j.estRouge () == true) : "La valeur n'est pas superieur ou egale a vigiMax";
	compteur++;
	
	//Le parametre de depart est superieur a vigieMax
	j = new JaugeNaturel (67899, 68000);
	assert (j.estRouge () == true) : "La valeur n'est pas superieur ou egale a vigieMax";
	compteur++;	

	//Le parametre de depart est nul et vigieMax > 0
	j = new JaugeNaturel (67899, 0); 
	assert (j.estRouge () == false) : "La valeur est superieur ou egale a vigieMax ";
	compteur++;

	//Le parametre de depart et vigieMax sont nuls (cas particulier)
	j = new JaugeNaturel (0, 0); 
	assert (j.estRouge () == true) : "La valeur n'est pas superieur ou egale a vigieMax";
	compteur++;

	//Le parametre de depart est negatif
	j = new JaugeNaturel (67899, -1);
	assert (j.estRouge () == false) : "La valeur est superieur ou egale a vigieMax ";
	compteur++;	

    }




void testInferieur () {
		
	//Le parametre de depart dans l'intervalle [0,vigieMax[
	JaugeNaturel j = new JaugeNaturel (67899, 100);
	assert (j.estBleu () == false) : "La valeur est strictement negative";
	compteur++;
	
	//Le parametre de depart est egal a vigieMax
	j = new JaugeNaturel (68000, 68000);
	assert (j.estBleu () == false) : "La valeur est strictement negative";
	compteur++;
	
	//Le parametre de depart est superieur a vigieMax
	j = new JaugeNaturel (67899, 68000);
	assert (j.estBleu () == false) : "La valeur est strictement negative";
	compteur++;	

	//Le parametre de depart est nul et vigieMax > 0
	j = new JaugeNaturel (67899, 0); 
	assert (j.estBleu () == false) : "La valeur est strictement negative";
	compteur++;

	//Le parametre de depart et vigieMax sont nuls (cas particulier)
	j = new JaugeNaturel (0, 0); 
	assert (j.estBleu () == false) : "La valeur est strictement negative";
	compteur++;

	//Le parametre de depart est negatif
	j = new JaugeNaturel (67899, -1);
	assert (j.estBleu () == true) : "La valeur n'est pas strictement negative";
	compteur++;	

    }


    void lancerTests(){
	System.out.println(".");	
	testDansIntervalle  ();
	System.out.println(".");
	testSuperieur ();
	System.out.println(".");
	testInferieur ();
	System.out.println("\nOK, " + compteur + " tests passés");
    }

}

