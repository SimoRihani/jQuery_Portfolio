package tec;

public class PassagerStandard {

    private String nom;

    private int destination;

	private EtatPassager etat;

    public PassagerStandard(String nom, int destination) {
	this.nom = nom;
	this.destination = destination;
	//this.assis = false;
	//this.debout = false;
	etat = new EtatPassager();
    }

    public String nom() {
	return this.nom;
    }

    public boolean estDehors() {
		return etat.estExterieur();
    }

    public boolean estAssis() {
		return etat.estAssis();
    }

    public boolean estDebout() {
		return etat.estDebout();
    }

    public void accepterSortie() {
	// if(this.assis)
// 	    this.assis = false;
// 	else
// 	    this.debout = false;
    }

    public void accepterPlaceAssise() {
	// if(this.debout)
	//     this.debout = false;
	// this.assis = true;
	etat = etat.assis();
    }

    public void accepterPlaceDebout() {
	// if(this.assis)
	//     this.assis = false;
	// this.debout = true;
	etat = etat.debout();
    }

    public void nouvelArret(Autobus bus, int numeroArret) {
	if (numeroArret == this.destination) {
	    accepterSortie();
	    bus.demanderSortie(this);
	}
	else if (numeroArret < this.destination)
	    bus.allerArretSuivant();
    }

    public void monterDans(Autobus t) { 
	if (t.aPlaceAssise())
	    t.demanderPlaceAssise(this);
	else if (t.aPlaceDebout())
	    t.demanderPlaceDebout(this);
    }

}