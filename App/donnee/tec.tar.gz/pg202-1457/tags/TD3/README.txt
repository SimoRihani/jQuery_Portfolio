Ce repertoire contient l'ensemble du code implémenté pendant le troisième TD de PG2020.

On y trouve quatre sous-répertoires :

Autobus	              contient les sources et les tests de l'implémentation de la classe Autobus en utilisant un faussaire de PassagerStandard
PassagerStandard      contient les sources et les tests de l'implémentation de la classe PassagerStandard en utilisant un faussaire de Autobus
Fusion		      répertoire dans lequel Autobus et PassagerStandard ont été fusionnés
	Ces trois répertoires contiennent un Makefile avec trois commandes principales :
	    make  	 compile les sources
	    make tests	 lance les tests
	    make clean vide les build

Relativement à la première partie du TD, un autre repertoire usagedefaux a été crée. Il contient un Makefile dont la règle make compile ET lance les tests.

L'arborescence globale de ce TD est la suivante :

├── Autobus
│   ├── build
│   ├── build-tst
│   ├── src
│   └── tst
├── Fusion
│   ├── build
│   ├── build-tstAutobus
│   ├── build-tstPassager
│   ├── recette
│   ├── src
│   ├── tstAutobus
│   └── tstPassager
├── PassagerStandard
│   ├── build
│   ├── build-tst
│   ├── src
│   └── tst
└── usageDeFaux
    ├── build
    ├── build-tst
    ├── src
    └── tst

