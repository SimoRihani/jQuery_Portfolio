package tec;

class TestAutobus {
			
    void testFaussaire() {
	Autobus a = new Autobus(0,0);
	PassagerStandard faux = new PassagerStandard();
	faux.estDehors();
	assert (faux.msg.get(1) == "estDehors");
	faux.estAssis();
	assert (faux.msg.get(2) == "estAssis");
	faux.estDebout();
	assert (faux.msg.get(3) == "estDebout");
	faux.accepterSortie();
	assert (faux.msg.get(4) == "accepterSortie");
	faux.accepterPlaceAssise();
	assert (faux.msg.get(5) == "accepterPlaceAssise");
	faux.accepterPlaceDebout();
	assert (faux.msg.get(6) == "accepterPlaceDebout");
	faux.nouvelArret(a,2);
	assert (faux.msg.get(7) == "nouvelArret");	
	assert (faux.msg.getLast() == "nouvelArret");
	assert (faux.msg.size() == 7);
	faux.msg.clear();
	assert (faux.msg.size() == 0);

    }	
	
    void testConstructeur() {
	Autobus a = new Autobus (7,0);
	assert a.aPlaceAssise() : "Le bus a 7 places assises";
	assert !a.aPlaceDebout() : "Le bus a 0 place debout";
	Autobus b = new Autobus (0,7);
	assert !b.aPlaceAssise() : "Le bus a 0 place assise";
	assert b.aPlaceDebout() : "Le bus a 7 places debouts";
    }
	
    void testDemanderPlaceAssise() {
	Autobus a = new Autobus(2,0);
	PassagerStandard p1 = new PassagerStandard ();
	PassagerStandard p2 = new PassagerStandard ();
	a.demanderPlaceAssise (p1);
	a.demanderPlaceAssise (p2);
	assert !a.aPlaceAssise ();
	assert (p1.msg.getLast().equals("accepterPlaceAssise"));
	//	assert (p2.msg.getLast() == "accepterPlaceAssise");
    }

	
    void testDemanderPlaceDebout() {
	Autobus a = new Autobus(0,2);
	PassagerStandard p1 = new PassagerStandard ();
	PassagerStandard p2 = new PassagerStandard ();
	a.demanderPlaceDebout (p1);
	a.demanderPlaceDebout (p2);
	assert !a.aPlaceDebout ();
	assert (p1.msg.getLast() == "accepterPlaceDebout");
	assert (p2.msg.getLast() == "accepterPlaceDebout");
    }

	
    void testDemanderSortie() {
	Autobus a = new Autobus(2,2);
	PassagerStandard p1 = new PassagerStandard();
	PassagerStandard p2 = new PassagerStandard();
	PassagerStandard p3 = new PassagerStandard();
	PassagerStandard p4 = new PassagerStandard();
	a.demanderPlaceAssise(p1);
	a.demanderPlaceDebout(p2);
	a.demanderPlaceAssise(p3);
	a.demanderPlaceDebout(p4);
	assert !a.aPlaceAssise ();
	assert !a.aPlaceDebout ();
	a.demanderSortie(p1);
	a.demanderSortie(p2);
	assert a.aPlaceAssise ();
	assert a.aPlaceDebout ();
	assert (p1.msg.getLast() == "accepterSortie");
	assert (p2.msg.getLast() == "accepterSortie");
    }
	
    void testAllerArretSuivant() {
	Autobus a = new Autobus(2,2);
	PassagerStandard p1 = new PassagerStandard();
	PassagerStandard p2 = new PassagerStandard();
	a.demanderPlaceAssise(p1);
	a.demanderPlaceDebout(p2);
	a.allerArretSuivant();
	assert (p1.msg.getLast() == "nouvelArret");
	assert (p2.msg.getLast() == "nouvelArret");
    }
	
    void testChangementPosition() {
	Autobus a = new Autobus(2,3);
	PassagerStandard p1 = new PassagerStandard();
	PassagerStandard p2 = new PassagerStandard();
	PassagerStandard p3 = new PassagerStandard();
	PassagerStandard p4 = new PassagerStandard();
	a.demanderPlaceAssise(p1);
	a.demanderPlaceDebout(p2);
	a.demanderPlaceDebout(p3);
	a.demanderPlaceAssise(p4);
	p1.msg.clear();
	p2.msg.clear();
	p3.msg.clear();
	p4.msg.clear();
	a.demanderChangerEnDebout(p1);
	assert (p1.msg.get(1) == "estAssis");
	assert (a.aPlaceAssise() && !a.aPlaceDebout());
	assert (p1.msg.get(2) == "accepterPlaceDebout");
	a.demanderChangerEnAssis(p2);
	assert (p2.msg.get(1) == "estDebout");
	assert (p2.msg.get(2) == "accepterPlaceAssise");

    }

    void lancer() {
	int nbTest = 0;
	
	System.out.println('.'); nbTest++;
	testConstructeur();
	System.out.println('.'); nbTest++;
	testFaussaire();
	System.out.println('.'); nbTest++;
	testDemanderPlaceAssise();
	System.out.println('.'); nbTest++;
	testDemanderPlaceDebout();
	System.out.println('.'); nbTest++;
	testDemanderSortie();
	System.out.println('.'); nbTest++;
	testAllerArretSuivant();
	System.out.println('.'); nbTest++;
	testChangementPosition();
	
	System.out.println("(" + nbTest + "):OK: " + getClass().getName());
    }
	
	

}
