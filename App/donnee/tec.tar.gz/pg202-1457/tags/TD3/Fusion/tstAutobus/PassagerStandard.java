package tec;

public class PassagerStandard {
    public Messages msg;
    public PassagerStandard() {
	msg = new Messages();
	msg.clear ();
    }
    public PassagerStandard(String nom, int destination) {
    }
    
    public String nom() {
	return null;
    }
    
    public boolean estDehors() {
	msg.add("estDehors");
	return true;
	}
    
    public boolean estAssis() {
	msg.add("estAssis");
	return true;
    }
    
    public boolean estDebout() {
	msg.add("estDebout");
	return true;
    }
    
    public void accepterSortie() {
	msg.add("accepterSortie");
    }
    
    public void accepterPlaceAssise() {	
	msg.add("accepterPlaceAssise");
    }
    
    public void accepterPlaceDebout() {
	msg.add("accepterPlaceDebout");
    }
    
    public void nouvelArret(Autobus bus, int numeroArret) {	    
	msg.add("nouvelArret");
	}
    
    public void monterDans(Autobus t) { 
	}
}
