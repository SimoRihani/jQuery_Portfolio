package tec;

class TestPassagerStandard {
    void testFaussaire() {
	Autobus bus = new Autobus();
	PassagerStandard p = new PassagerStandard("p", 0);
	bus.aPlaceAssise ();
	assert (bus.msg.get(1).equals ("aPlaceAssise"));
	bus.aPlaceDebout ();
	assert (bus.msg.get(2).equals ("aPlaceDebout"));
	bus.demanderPlaceAssise (p);
	assert (bus.msg.get(3).equals ("demanderPlaceAssise"));
	bus.demanderPlaceDebout (p);
	assert (bus.msg.get(4).equals ("demanderPlaceDebout"));
	bus.demanderSortie (p);
	assert (bus.msg.get(5).equals ("demanderSortie"));
	bus.allerArretSuivant ();
	assert (bus.msg.get(6).equals ("allerArretSuivant"));
	assert (bus.msg.getLast().equals ("allerArretSuivant"));
	assert (bus.msg.size () == 6);
	bus.msg.clear ();
	assert (bus.msg.size () == 0);
    }

    void testConstructeur() {
	PassagerStandard p = new PassagerStandard ("p", 0);
	assert p.estDehors ();
	assert !p.estAssis ();
	assert !p.estDebout ();	
    }

    void testAccepterPlaceAssise () {
	PassagerStandard p = new PassagerStandard ("p", 0);
	p.accepterPlaceAssise ();
	assert !p.estDehors ();
	assert p.estAssis ();
	assert !p.estDebout ();	
    }


    void testAccepterPlaceDebout () {
	PassagerStandard p = new PassagerStandard ("p", 0);
	p.accepterPlaceDebout ();
	assert !p.estDehors ();
	assert !p.estAssis ();
	assert p.estDebout ();	
    }


    void testAccepterSortie () {
	PassagerStandard p = new PassagerStandard ("p", 0);
	p.accepterSortie ();
	assert p.estDehors ();
	assert !p.estAssis ();
	assert !p.estDebout ();	
    }

    void testMonterDans () {
	Autobus bus = new Autobus ();
	PassagerStandard p = new PassagerStandard ("p", 0);
	p.monterDans (bus);
	assert (bus.msg.get(1).equals ("aPlaceAssise"));
	assert (bus.msg.get(2).equals ("aPlaceDebout"));
	assert (bus.msg.getLast().equals ("demanderPlaceDebout"));
    }

    void testNouvelArret () {
	Autobus bus = new Autobus ();
	PassagerStandard p = new PassagerStandard ("p", 2);
	p.nouvelArret (bus, 1);
	assert bus.msg.getLast().equals ("allerArretSuivant");
	p.nouvelArret (bus, 2);
	assert bus.msg.getLast().equals ("demanderSortie");
    }

   
    void lancer() {
	int nbTest = 0;
	
	System.out.println('.'); nbTest++;
	testFaussaire();
	System.out.println('.'); nbTest++;
	testConstructeur();
	System.out.println('.'); nbTest++;
	testAccepterSortie();
	System.out.println('.'); nbTest++;
	testAccepterPlaceAssise();
	System.out.println('.'); nbTest++;
	testAccepterPlaceDebout();
	System.out.println('.'); nbTest++;
	testNouvelArret();
	System.out.println('.'); nbTest++;
	testMonterDans();
	
	System.out.println("(" + nbTest + "):OK: " + getClass().getName()); 
    }
}
