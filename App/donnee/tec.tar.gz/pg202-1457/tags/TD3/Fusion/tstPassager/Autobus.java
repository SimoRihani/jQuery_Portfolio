package tec;

public class Autobus {
    public Messages msg;
    public Autobus() {
	msg = new Messages();
	msg.clear ();
    }
    
    public Autobus(int assis, int debout) {
    }

    public boolean aPlaceAssise() {
	msg.add("aPlaceAssise");
	return false;
    }

    public boolean aPlaceDebout() {
	msg.add("aPlaceDebout");
	return true;
    }

    public void demanderPlaceAssise(PassagerStandard p) {
	msg.add ("demanderPlaceAssise");
    }

    public void demanderPlaceDebout(PassagerStandard p) {
	msg.add ("demanderPlaceDebout");
    }

    public void demanderSortie(PassagerStandard p) {
	msg.add ("demanderSortie");
    }

    public void demanderChangerEnDebout(PassagerStandard p) {
    }

    public void demanderChangerEnAssis(PassagerStandard p) {
    }

    public void allerArretSuivant() {
	msg.add ("allerArretSuivant");
    }
}
