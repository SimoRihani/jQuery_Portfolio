package tec;

public class Autobus implements Bus,Transport {
    private int arret;
    private JaugeNaturel jaugeAssis;
    private JaugeNaturel jaugeDebout;
    private Passager passagers[];
    private int nbrePassagers;  
    /*
     * Instanciation
     */
    public Autobus(int assis, int debout) {
	jaugeAssis = new JaugeNaturel(assis, 0);
	jaugeDebout = new JaugeNaturel(debout, 0);
	passagers = new Passager[assis + debout];
	nbrePassagers = 0;
	arret = 0;
    }
    

    /*
     * Au moins une place assise est disponible
     */
    public boolean aPlaceAssise() {
	return jaugeAssis.estVert();
    }
    


    /*
     * Au moins une place debout est disponible
     */
    public boolean aPlaceDebout() {
	return jaugeDebout.estVert();
    }


    /*
     *Le passager est en dehors du bus et demande une place assise 
     */
    public void demanderPlaceAssise(Passager p) {
	if (aPlaceAssise()) {
	    p.accepterPlaceAssise();
	    jaugeAssis.incrementer();
	    passagers[nbrePassagers] = p;
	    nbrePassagers++;
	}
    }


    /*
     *Le passager est en dehors du bus et demande une place debout 
     */
    
    public void demanderPlaceDebout(Passager p) {
	if (aPlaceDebout()) {
	    p.accepterPlaceDebout();
	    jaugeDebout.incrementer();
	    passagers[nbrePassagers] = p;
	    nbrePassagers++;
	}
    }
    
    
    /*
     * Fait sortir un passager du bus (le passager doit etre dans le bus)
     */

    public void demanderSortie(Passager p) {
	if (p.estAssis()) 
	    jaugeAssis.decrementer();
	    
	if (p.estDebout()) 
	    jaugeDebout.decrementer();
	
	p.accepterSortie();
	retirerPassager (rechercherPassager (p));
    }
    
    
    public void demanderChangerEnDebout(Passager p) {
	if (p.estAssis () && aPlaceDebout()) {
	    p.accepterPlaceDebout();
	    jaugeAssis.decrementer();
	    jaugeDebout.incrementer();
	}
    }
    

    public void demanderChangerEnAssis(Passager p) {
	if (p.estDebout() && aPlaceAssise()) {
	    p.accepterPlaceAssise();
	    jaugeDebout.decrementer();
	    jaugeAssis.incrementer();
	}
    }
    
    
    public void allerArretSuivant() {
	int i = 0;
	arret++;
	for (i = 0 ; i < nbrePassagers ; i++)
	    passagers[i].nouvelArret(this, arret);
    }


    /*
     * Pour la suppression des passagers qui sortent
     */
    private int rechercherPassager (Passager p) {
	int i = 0;
	for (i = 0; i < nbrePassagers; i++)
	    if (passagers[i] == p) //verification de reference
		return i;
	return -1;
    }


    private void retirerPassager (int index) {
	int i = index;
	for (i = index; i < nbrePassagers - 1; i++)
	    passagers[i] = passagers[i + 1];
	nbrePassagers--;
    }
    
}

