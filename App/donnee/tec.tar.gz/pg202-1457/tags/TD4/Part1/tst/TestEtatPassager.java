package tec;

class TestEtatPassager{
    int compteur = 0;
    void lancer(){
	compteur = 0;
	System.out.println(".");
	testConstructeur();
	System.out.println(".");
	testDehors();
	System.out.println(".");
	testAssis();
	System.out.println(".");
	testDebout();

	System.out.println("\nOK, " + compteur + " tests passés");
    }

    void testConstructeur(){ // le constructeur doit construire une instance dans l'état DEHORS du passager (d'après la doc)
	EtatPassager e = new EtatPassager(); 
	assert e.estExterieur() == true : "le passager doit être dehors";
	assert e.estInterieur() == false : "le passager doit être dehors";	
	assert e.estAssis() == false : "un passager qui est dehors n'est pas compté comme assis";
	assert e.estDebout() == false : "un passager qui est dehors n'est pas compté comme debout";
	ajouteTests(4);
    }

    void testDehors(){
	EtatPassager e = new EtatPassager();
	e = e.dehors();
	assert e.estExterieur() == true : "le passager doit être dehors";
	assert e.estInterieur() == false : "le passager doit être dehors";	
	assert e.estAssis() == false : "un passager qui est dehors n'est pas compté comme assis";
	assert e.estDebout() == false : "un passager qui est dehors n'est pas compté comme debout";    
	ajouteTests(4);
    }

    void testAssis(){
	EtatPassager e = new EtatPassager();
	e = e.assis();
	assert e.estExterieur() == false : "un passager assis est compté comme à l'intérieur";
	assert e.estInterieur() == true : "un passager assis est compté comme à l'intérieur";	
	assert e.estAssis() == true : "le passager doit être assis";
	assert e.estDebout() == false : "un passager assis n'est pas debout";
	ajouteTests(4);
    }    

    void testDebout(){
	EtatPassager e = new EtatPassager();
	e = e.debout();
	assert e.estExterieur() == false : "un passager debout est compté comme à l'intérieur";
	assert e.estInterieur() == true : "un passager debout est compté comme à l'intérieur";	
	assert e.estAssis() == false : "un passager debout n'est pas assis";
	assert e.estDebout() == true : "le passager doit être debout";
	ajouteTests(4);
    }   

    void ajouteTests(int i){
	compteur += i;
    }
}