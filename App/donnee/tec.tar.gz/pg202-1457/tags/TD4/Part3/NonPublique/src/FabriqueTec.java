package tec;

public final class FabriqueTec {
    public static PassagerStandard fairePassagerStandard(String nom, int destination){
		return new PassagerStandard(nom, destination);
    }

    public static Autobus faireAutobus(int assis, int debout){
		return new Autobus(assis, debout);
    }
}