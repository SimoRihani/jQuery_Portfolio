package tec;

public class LancerTests {
	public static void main(String... args) {
		boolean estMisAssertion = false;
		assert estMisAssertion = true;

		if (!estMisAssertion) {
			System.out.println("Execution impossible sans l'option -ea");
			return;
		}


		try{
			lancer(TestEtatPassager.class);
			lancer(TestPassagerStandard.class);
			lancer(TestJaugeNaturel.class);
			lancer(TestAutobus.class);
		}
		catch (Exception e){
			System.out.println("Erreur lors des tests : ");
			e.printStackTrace();
		}
	}
	
	
	static private void lancer(Class c) throws Exception{
		Object o = c.newInstance();
		java.lang.reflect.Method[] mesMethodes = c.getDeclaredMethods();
		int nbTest = 0;
		for (int i = 0; i < mesMethodes.length; i++) {
			java.lang.reflect.Method m = mesMethodes[i];
			if (m.getName().startsWith("test")){
				System.out.print(".");
				m.invoke(o);
				nbTest++;
			}
		}
		System.out.println("(" + nbTest + "):OK: " + o.getClass().getName());
	}

	// TestPassagerStandard tPS = new TestPassagerStandard();
	// tPS.lancer();
	//
	// TestAutobus tA = new TestAutobus();
	// tA.lancer();
	//
	// TestJaugeNaturel tJN = new TestJaugeNaturel();
	// tJN.lancer();
	//
	// TestEtatPassager tEP = new TestEtatPassager();
	// tEP.lancer();
	

	/*
	// comment lancer les tests ?
		
	System.out.println("Début des tests de JaugeNaturel");
	TestJaugeNaturel t2 = new TestJaugeNaturel();
	t2.lancerTests(); 
	*/
  
}
