package tec;

class TestPassagerStandard {
    void testAccesseurs() {
	PassagerStandard p = new PassagerStandard("p", 0);
	assert p.nom() == "p" : "le nom doit être celui donné au constructeur";
	assert p.estDehors() == true : "par défaut un passager est dehors";
	assert p.estAssis() == false : "par défaut un passager est dehors";
	assert p.estDebout() == false : "par défaut un passager est dehors";
	
    }

    void testAccepterSortie() {
	PassagerStandard p = new PassagerStandard("p", 0);
	p.accepterSortie();
	assert p.estDehors() == true : "le passager doit être sorti";
	assert p.estAssis() == false : "un passager dehors n'est pas assis";
	assert p.estDebout() == false : "un passager dehors n'est pas debout";
    }

    void testAccepterPlaceAssise() {
	PassagerStandard p = new PassagerStandard("p", 0);
	p.accepterPlaceAssise();
	assert p.estDehors() == false : "le passager doit être dans un bus";
	assert p.estAssis() == true : "le passager doit être assis";
	assert p.estDebout() == false : "le passager doit être assis";	
    }

    void testAccepterPlaceDebout() {
	PassagerStandard p = new PassagerStandard("p", 0);
	p.accepterPlaceDebout();
	assert p.estDehors() == false : "le passager doit être dans un bus";
	assert p.estAssis() == false : "le passager doit être debout";  
	assert p.estDebout() == true : "le passager doit être debout";
    }

    void testNouvelArret() {
	PassagerStandard p = new PassagerStandard("p", 2);
	FauxBus bus = new FauxBus(0, 0);
	//System.out.print("Le passager doit demander à aller à l'arrêt suivant : ");
	p.nouvelArret(bus, 1);
	//System.out.print("Le passage doit demander à sortir du bus : ");
	p.nouvelArret(bus, 2);
    }

    void testMonterDans() {
	PassagerStandard p = new PassagerStandard("p", 0);
	FauxBus vide = new FauxBus(0, 0);
	//System.out.println("Le passager essaie de monter dans un bus vide");
	p.monterDans(vide);

	FauxBus placesDebout = new FauxBus(0, 1);	
	//System.out.println("Le passager essaie de monter dans un bus qui ne dispose que de places debout");
	p.monterDans(placesDebout);
    }
    
    void lancer() {
	int nbTest = 0;
	
	System.out.println('.'); nbTest++;
	testAccesseurs();
	System.out.println('.'); nbTest++;
	testAccepterSortie();
	System.out.println('.'); nbTest++;
	testAccepterPlaceAssise();
	System.out.println('.'); nbTest++;
	testAccepterPlaceDebout();
	System.out.println('.'); nbTest++;
	testNouvelArret();
	System.out.println('.'); nbTest++;
	testMonterDans();

	System.out.println("(" + nbTest + "):OK: " + getClass().getName()); 
    }
}