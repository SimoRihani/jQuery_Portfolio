package tec;

public class FauxPassager implements Passager, Usager{
    public Messages msg;
    public FauxPassager(String nom, int destination) {
	msg = new Messages();
	msg.clear ();
    }

    public String nom() {
	return null;
    }
    
    public boolean estDehors() {
	msg.add("estDehors");
	return true;
	}
    
    public boolean estAssis() {
	msg.add("estAssis");
	return true;
    }
    
    public boolean estDebout() {
	msg.add("estDebout");
	return true;
    }
    
    public void accepterSortie() {
	msg.add("accepterSortie");
    }
    
    public void accepterPlaceAssise() {	
	msg.add("accepterPlaceAssise");
    }
    
    public void accepterPlaceDebout() {
	msg.add("accepterPlaceDebout");
    }
    
    public void nouvelArret(Bus bus, int numeroArret) {	    
	msg.add("nouvelArret");
	}
    
    public void monterDans(Transport t) { 
	}
}
