package tec;

public interface Comportement {

    abstract void choixChangerPlace (Bus b, int arret, Passager p);

}
