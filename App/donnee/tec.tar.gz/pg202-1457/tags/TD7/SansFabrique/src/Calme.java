package tec;

public class Calme implements Comportement {
    static Comportement Singleton = new Calme();
    private Calme () {
    }
    public void choixChangerPlace (Bus b, int arret, Passager p) {
	
    }

}
 
