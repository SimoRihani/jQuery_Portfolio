package tec;

public abstract class Repos extends PassagerAbstrait {
    public Repos (String nom, int arret, Comportement c) {
	super (nom,arret,c);
    }

    public void choixPlaceMontee(Bus b) { 
	if (b.aPlaceAssise())
	    b.demanderPlaceAssise(this);
	else if (b.aPlaceDebout())
	    b.demanderPlaceDebout(this);
    }
}
