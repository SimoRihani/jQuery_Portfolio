package tec;

public class Poli implements Comportement {
    static Comportement Singleton = new Poli();    
    private Poli () {
    }
    public void choixChangerPlace (Bus b, int arret, Passager p) {
	if (!b.aPlaceAssise())
	    b.demanderChangerEnDebout(p);    
    }
}
