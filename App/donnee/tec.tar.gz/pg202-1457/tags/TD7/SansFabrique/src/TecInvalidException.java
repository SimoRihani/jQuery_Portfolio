package tec;

public class TecInvalidException extends java.lang.Exception {

    public TecInvalidException(String s ) {
	super(s);
    }
    public TecInvalidException(String s, Throwable c) {
	super(s, c);
    }
}
