package tec;

public abstract class Fatigue extends PassagerAbstrait {
    public Fatigue (String nom, int destination, Comportement c) {
	super (nom,destination, c);
    }
    public void choixPlaceMontee(Bus b) throws IllegalStateException { 
	if (b.aPlaceAssise())
	try{
            b.demanderPlaceAssise(this);
					} catch(IllegalStateException e){
						throw new IllegalStateException();
					}
    }
}
