package tec;

public class PassagerStandard extends Repos {

    public PassagerStandard (String nom, int destination){
	super(nom, destination, Calme.Singleton);
	//comportement = Calme.Singleton;    
    }   
}
