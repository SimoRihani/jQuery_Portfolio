package tec;

public class PassagerStresse extends Fatigue {
    public PassagerStresse (String nom, int destination){
	super(nom, destination, Prudent.Singleton);
	//	comportement = Prudent.Singleton;
    }   
}
