package tec;
public abstract class Tetu extends PassagerAbstrait {
    public Tetu (String nom, int arret, Comportement c) {
	super (nom,arret,c);
    }

    public void choixPlaceMontee(Bus b) { 
	b.demanderPlaceDebout(this);
    }
}
