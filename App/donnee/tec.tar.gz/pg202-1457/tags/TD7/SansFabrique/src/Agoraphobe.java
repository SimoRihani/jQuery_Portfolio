package tec;

class Agoraphobe implements Comportement {
    static Comportement Singleton = new Agoraphobe ();
    private Agoraphobe () {
    }
    public void choixChangerPlace (Bus b, int arret, Passager p) {
	if (!b.aPlaceAssise() || !b.aPlaceDebout())
	    b.demanderSortie(p);
    }
}
 
