package tec;

public class PassagerLunatique extends Sportif {
    public PassagerLunatique (String nom, int destination){
	super(nom, destination, Nerveux.Singleton);
	//comportement = Nerveux.Singleton;
    }   
}
