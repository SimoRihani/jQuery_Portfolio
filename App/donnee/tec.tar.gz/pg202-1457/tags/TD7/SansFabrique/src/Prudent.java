package tec;

public class Prudent implements Comportement {
    static Comportement Singleton = new Prudent ();
    private Prudent (){
    }
    public void choixChangerPlace (Bus b, int arret, Passager p) {
	
	if(((PassagerAbstrait)p).timeToDest(arret) < 4 && b.aPlaceDebout())
	    b.demanderPlaceDebout(p);	
    }
}
