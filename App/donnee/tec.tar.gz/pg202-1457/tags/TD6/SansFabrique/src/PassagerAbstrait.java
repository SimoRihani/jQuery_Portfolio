package tec;

public abstract class PassagerAbstrait implements Passager, Usager{
    
    private String nom;
    
    private int destination;
    
    // si assis et debout valent false, le passager est dehors
    private boolean assis; // true si le passager est assis
    private boolean debout; //true si le passager est debout
    protected Comportement comportement;    
    public PassagerAbstrait(String nom, int destination) {
	this.nom = nom;
	this.destination = destination;
	this.assis = false;
	this.debout = false;
	//	comportement = c;
    }
    
    public String nom() {
	return this.nom;
    }
    
    public boolean estDehors() {
		return !(this.assis || this.debout);
    }
    
    public boolean estAssis() {
	return this.assis;
    }
    
    public boolean estDebout() {
	return this.debout;
    }
    
    public void accepterSortie() {
	if(this.assis)
	    this.assis = false;
	else
	    this.debout = false;
    }
    
    public void accepterPlaceAssise() {
	if(this.debout)
	    this.debout = false;
	this.assis = true;
    }
    
    public void accepterPlaceDebout() {
		if(this.assis)
	    this.assis = false;
	this.debout = true;
	    }
    
    public int timeToDest(int arretCourant) {
	return (this.destination - arretCourant);
    }

    public abstract void choixPlaceMontee(Bus b);

    public final void monterDans(Transport t) {
			Bus b = (Bus) t;
			choixPlaceMontee(b);
    }

    public final void nouvelArret(Bus b, int numeroArret) {
	if (timeToDest(numeroArret) == 0) {
	    accepterSortie();
	    b.demanderSortie(this);
	}
	comportement.choixChangerPlace(b, numeroArret,this);
    }

    @Override
    public String toString() {
	if (this.assis) 
	    return nom + " assis";
	else 
	    return nom + " debout";
    }
    
}
