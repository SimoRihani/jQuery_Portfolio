package tec;

public class Prudent implements Comportement {
    static Prudent prudent = new Prudent ();
    public void choixChangerPlace (Bus b, int arret, Passager p) {
	
	if(((PassagerAbstrait)p).timeToDest(arret) < 4 && b.aPlaceDebout())
	    b.demanderPlaceDebout(p);	
    }
}
