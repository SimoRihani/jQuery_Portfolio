package tec;

public class Calme implements Comportement {
    static Calme calme = new Calme();
    public void choixChangerPlace (Bus b, int arret, Passager p) {
	
    }

}
 
