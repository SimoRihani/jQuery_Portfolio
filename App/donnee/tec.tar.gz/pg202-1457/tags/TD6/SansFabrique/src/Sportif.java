package tec;

public abstract class Sportif extends PassagerAbstrait {
    public Sportif (String nom, int arret) {
	super (nom,arret);
    }

     public void choixPlaceMontee(Bus b) {
	if (b.aPlaceDebout())
	    b.demanderPlaceDebout(this);
    }
}
