package tec;
public abstract class Tetu extends PassagerAbstrait {
    public Tetu (String nom, int arret) {
	super (nom,arret);
    }

    public void choixPlaceMontee(Bus b) { 
	b.demanderPlaceDebout(this);
    }
}
