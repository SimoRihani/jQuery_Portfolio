package tec;

public class Nerveux implements Comportement {
    static Nerveux nerveux = new Nerveux ();    
    public void choixChangerPlace (Bus b, int arret, Passager p) {
	if (p.estAssis())
	    b.demanderChangerEnDebout(p);
	else
	    b.demanderChangerEnAssis(p);
    }
    
}
