package tec;

class Agoraphobe implements Comportement {
    static Agoraphobe agoraphobe = new Agoraphobe ();
    public void choixChangerPlace (Bus b, int arret, Passager p) {
	if (!b.aPlaceAssise() || !b.aPlaceDebout())
	    b.demanderSortie(p);
    }
}
 
