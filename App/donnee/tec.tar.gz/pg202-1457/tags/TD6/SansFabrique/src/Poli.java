package tec;

public class Poli implements Comportement {
    static Poli poli = new Poli();    
    public void choixChangerPlace (Bus b, int arret, Passager p) {
	if (!b.aPlaceAssise())
	    b.demanderChangerEnDebout(p);    
    }
}
