package tec;

public class PassagerLunatique extends Sportif {
    public PassagerLunatique (String nom, int destination){
	super(nom, destination);
	comportement = Nerveux.nerveux;
    }   
}
