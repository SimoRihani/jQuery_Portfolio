package tec;

class TestPassagerLunatique extends TestPassagerAbstrait {
   
  
		void testChoixChangerPlace() {
		    PassagerLunatique p = new PassagerLunatique("p",1);
		    Autobus bus = new Autobus(1,1);
		    p.monterDans(bus);
		    
		    assert p.estAssis() == false : "Il ne peut pas prendre de place assise";
		    assert p.estDebout() == true : "Il prend la place debout";
		    p.comportement.choixChangerPlace(bus,0,p);
		    
		    assert p.estDehors() == false : "Il est bien à l'interieur";
		    assert p.estAssis() == true : "Il change de place et s'asseoit";
		    assert p.estDebout() == false : "Il change de place et n'est plus débout";
			
		    p.comportement.choixChangerPlace(bus,0,p);
		    
		    assert p.estDehors() == false : "Il est bien à l'interieur";
		    assert p.estAssis() == false : "Il change de place n'est plus assis";
		    assert p.estDebout() == true : "Il change de place et redeviens debout";
		    
		    bus.allerArretSuivant();
			
		    p.comportement.choixChangerPlace(bus,1,p);
		    
		    assert p.estDehors() == true : "Le passager est arrivé à sa destination";
		    assert p.estAssis() == false : "Le passager est sortis du bus";
		    assert p.estDebout() == false : "Le passager est sortis du bus";
		    
		}
    
    void testChoixPlaceMontee() {
	PassagerLunatique p1 = new PassagerLunatique("p",1);
	Autobus busDebout = new Autobus(0,1);
	p1.choixPlaceMontee(busDebout);
	assert p1.estDebout() == true :"Il monte et prend une place debout";
	assert p1.estAssis() == false :"Il ne peut prendre qu'une place debout";
	assert p1.estDehors() == false :"Il y'a une place disponible debout";
	
	PassagerLunatique p2 = new PassagerLunatique("p",1);
	Autobus busAssis = new Autobus(1,0);
	p2.choixPlaceMontee(busAssis);
	assert p2.estDebout() == false :"Il n'y a pas de place debout";
	assert p2.estAssis() == false :"Il ne peut pas prendre de place assise";
	assert p2.estDehors() == true:"Que des places assise il ne peut pas monter";
		}
    
    void lancer() {
	int nbTest = 0;
	
	System.out.println('.'); nbTest++;
	testChoixPlaceMontee();
	System.out.println('.'); nbTest++;
	testChoixChangerPlace();
	System.out.println("(" + nbTest + "):OK: " + getClass().getName()); 
    }
}
