package tec;

class TestPassagerStandard extends TestPassagerAbstrait {

    void testNouvelArret() {
	PassagerStandard p = new PassagerStandard("p", 2);
	FauxBus bus = new FauxBus(0, 0);
	//System.out.print("Le passager doit demander à aller à l'arrêt suivant : ");
	p.nouvelArret(bus, 1);
	//System.out.print("Le passage doit demander à sortir du bus : ");
	p.nouvelArret(bus, 2);
    }

    void testMonterDans() {
	PassagerStandard p = new PassagerStandard("p", 0);
	FauxBus vide = new FauxBus(0, 0);
	//System.out.println("Le passager essaie de monter dans un bus vide");
	p.monterDans(vide);

	FauxBus placesDebout = new FauxBus(0, 1);	
	//System.out.println("Le passager essaie de monter dans un bus qui ne dispose que de places debout");
	p.monterDans(placesDebout);
    }
    
    void lancer() {
	int nbTest = 0;
	
	System.out.println('.'); nbTest++;
	testNouvelArret();
	System.out.println('.'); nbTest++;
	testMonterDans();

	System.out.println("(" + nbTest + "):OK: " + getClass().getName()); 
    }
}