Ce repertoire contient l'ensemble du code implémenté pendant le sixième TD de PG2020.

On y trouve les sous-répertoires AvecFabrique et SansFabrique.

À l'implémentation près, les deux répertoires sont identiques et contiennent tout deux un Makefile avec trois commandes principales :
    make         compile les sources et lance le scnénario de recette/Simple.java
    make tests   compile et lance les tests
    make clean   vide les build


