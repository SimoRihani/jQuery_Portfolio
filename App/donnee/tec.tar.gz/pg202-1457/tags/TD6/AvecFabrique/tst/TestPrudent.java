package tec;

class TestPrudent extends TestPassagerAbstrait {

    protected PassagerAbstrait creerPassager(String nom, int destination, Comportement comp) {
	return (PassagerAbstrait) new FauxComportementMontee(nom,destination,comp);
    }

    void testChoixChangerPlace() {
	Autobus b1 = new Autobus(1,1);
	Comportement c = new Prudent();
	PassagerAbstrait p = creerPassager("p", 5, c);
	b1.demanderPlaceAssise(p);
	c.choixChangerPlace(b1,0,p);
	assert p.estAssis() == true : "il n'ya que des places assises";
    
	c.choixChangerPlace(b1, 4, p);
	assert p.estDebout() == true : "il arrive bientot a sa destination";
    }

    void testCodeConstant() {
	int nbTest = 0;
	
	nbTest++;
	testAccepterSortie();
	nbTest++;
	testAccepterPlaceDebout();
	nbTest++;
	testAccepterPlaceAssise();
	nbTest++;
	testAccesseurs();
    }
}