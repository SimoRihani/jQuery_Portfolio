package tec;

/* Les assertions verifiant les instanciations ainsi que les methodes incrementer() et decrementer() seront traitees dans la partie 3 (une fois qu'on aura ajoute la methode d'acces valeur() ) 
 */

class TestJaugeNaturel {
       
    int compteur = 0;  // pour comptabiliser le nombre de tests effectues

    public static void testExceptionCasLimites(){
        JaugeNaturel inverse;
       try{
            inverse = new JaugeNaturel(-42,-10);
            assert(false): "doit lever une exception";
        }catch(IllegalArgumentException e){
            assert(true): "exception levée !";
        }
        //inverse.decrementer();//si on veut que le compilateur rale pour instance non initialisée.
    }

    void testDansIntervalle () {
		
	//Le parametre de depart dans l'intervalle [0,vigieMax[
	JaugeNaturel j = new JaugeNaturel (67899, 100);
	assert (j.estVert () == true) : "La valeur n'est pas dans l'intervalle";
	compteur++;
	
	//Le parametre de depart est egal a vigieMax
	j = new JaugeNaturel (68000, 68000);
	assert (j.estVert () == false) : "La valeur est dans l'intervalle";
	compteur++;
	
	//Le parametre de depart est superieur a vigieMax
	j = new JaugeNaturel (67899, 68000);
	assert (j.estVert () == false) : "La valeur est dans l'intervalle";
	compteur++;	

	//Le parametre de depart est nul et vigieMax > 0
	j = new JaugeNaturel (67899, 0); 
	assert (j.estVert () == true) : "La valeur n'est pas dans l'intervalle";
	compteur++;

	//Le parametre de depart et vigieMax sont nuls (cas particulier)
	j = new JaugeNaturel (0, 0); 
	assert (j.estVert () == false) : "La valeur de depart est dans l'intervalle";
	compteur++;

	//Le parametre de depart est negatif
	j = new JaugeNaturel (67899, -1);
	assert (j.estVert () == false) : "La valeur est dans l'intervalle";
	compteur++;	

    }



    void testSuperieur () {
		
	//Le parametre de depart dans l'intervalle [0,vigieMax[
	JaugeNaturel j = new JaugeNaturel (67899, 100);
	assert (j.estRouge () == false) : "La valeur est superieur a vigieMax";
	compteur++;
	
	//Le parametre de depart est egal a vigieMax
	j = new JaugeNaturel (68000, 68000);
	assert (j.estRouge () == true) : "La valeur n'est pas superieur ou egale a vigiMax";
	compteur++;
	
	//Le parametre de depart est superieur a vigieMax
	j = new JaugeNaturel (67899, 68000);
	assert (j.estRouge () == true) : "La valeur n'est pas superieur ou egale a vigieMax";
	compteur++;	

	//Le parametre de depart est nul et vigieMax > 0
	j = new JaugeNaturel (67899, 0); 
	assert (j.estRouge () == false) : "La valeur est superieur ou egale a vigieMax ";
	compteur++;

	//Le parametre de depart et vigieMax sont nuls (cas particulier)
	j = new JaugeNaturel (0, 0); 
	assert (j.estRouge () == true) : "La valeur n'est pas superieur ou egale a vigieMax";
	compteur++;

	//Le parametre de depart est negatif
	j = new JaugeNaturel (67899, -1);
	assert (j.estRouge () == false) : "La valeur est superieur ou egale a vigieMax ";
	compteur++;	

    }




void testInferieur () {
		
	//Le parametre de depart dans l'intervalle [0,vigieMax[
	JaugeNaturel j = new JaugeNaturel (67899, 100);
	assert (j.estBleu () == false) : "La valeur est strictement negative";
	compteur++;
	
	//Le parametre de depart est egal a vigieMax
	j = new JaugeNaturel (68000, 68000);
	assert (j.estBleu () == false) : "La valeur est strictement negative";
	compteur++;
	
	//Le parametre de depart est superieur a vigieMax
	j = new JaugeNaturel (67899, 68000);
	assert (j.estBleu () == false) : "La valeur est strictement negative";
	compteur++;	

	//Le parametre de depart est nul et vigieMax > 0
	j = new JaugeNaturel (67899, 0); 
	assert (j.estBleu () == false) : "La valeur est strictement negative";
	compteur++;

	//Le parametre de depart et vigieMax sont nuls (cas particulier)
	j = new JaugeNaturel (0, 0); 
	assert (j.estBleu () == false) : "La valeur est strictement negative";
	compteur++;

	//Le parametre de depart est negatif
	j = new JaugeNaturel (67899, -1);
	assert (j.estBleu () == true) : "La valeur n'est pas strictement negative";
	compteur++;	

    }


    void lancer(){
	System.out.println(".");	
	testExceptionCasLimites();
	System.out.println(".");	
	testDansIntervalle  ();
	System.out.println(".");
	testSuperieur ();
	System.out.println(".");
	testInferieur ();
	System.out.println("\nOK, " + compteur + " tests passés");
    }

}

