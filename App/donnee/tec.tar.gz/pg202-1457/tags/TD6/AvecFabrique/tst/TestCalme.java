package tec;

class TestCalme extends TestPassagerAbstrait {

    protected PassagerAbstrait creerPassager(String nom, int destination, Comportement comp) {
	return (PassagerAbstrait) new FauxComportementMontee(nom,destination,comp);
    }

    void testChoixChangerPlace() {
	Autobus b1 = new Autobus(2,2);
	Comportement c1 = new Calme();
	PassagerAbstrait p1 = creerPassager("p1", 5, c1);
	b1.demanderPlaceAssise(p1);
	c1.choixChangerPlace(b1,0,p1);
	assert p1.estAssis() == true : "il reste des places assises et debouts, p1 ne bouge pas";

	Autobus b2 = new Autobus(1,1);
	Comportement c2 = new Calme();
	PassagerAbstrait p2 = creerPassager("p2", 5, c2);
	b2.demanderPlaceAssise(p2);
	c2.choixChangerPlace(b2,0,p2);
	assert p2.estAssis() == true : "il ne reste ni de places assises ni de places debouts, p2 ne bouge pas";    
    }

    void testCodeConstant() {
	int nbTest = 0;
	
	nbTest++;
	testAccepterSortie();
	nbTest++;
	testAccepterPlaceDebout();
	nbTest++;
	testAccepterPlaceAssise();
	nbTest++;
	testAccesseurs();
    }
}