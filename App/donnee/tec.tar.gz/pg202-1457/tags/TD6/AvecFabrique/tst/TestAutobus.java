package tec;

class TestAutobus {
			
	void testConstructeur() {
		Autobus a = new Autobus (7,0);
		assert a.aPlaceAssise() : "Le bus a 7 places assises";
		assert !a.aPlaceDebout() : "Le bus a 0 place debout";
		Autobus b = new Autobus (0,7);
		assert !b.aPlaceAssise() : "Le bus a 0 place assise";
		assert b.aPlaceDebout() : "Le bus a 7 places debouts";
	}
	
	void testDemanderPlaceAssise() {
		Autobus busA = new Autobus(7,0);
		for (int i = 0 ; i<7 ; i++) {
			FauxPassager p = new FauxPassager("p", 2);
			busA.demanderPlaceAssise(p);	
		}
	}
	
	void testDemanderPlaceDebout() {
		Autobus busD = new Autobus(0,7);
		//System.out.println("7 passager doivent accepter une place debout");	
		for (int i = 0 ; i<7 ; i++) {
			FauxPassager p = new FauxPassager("p", 2);
			busD.demanderPlaceDebout(p);	
		}
	}
	
	void testDemanderSortie() {
		Autobus bus = new Autobus(2,2);
		FauxPassager p1 = new FauxPassager("p1",2);
		FauxPassager p2 = new FauxPassager("p2",2);
		FauxPassager p3 = new FauxPassager("p3",2);
		FauxPassager p4 = new FauxPassager("p4",2);
		bus.demanderPlaceAssise(p1);
		bus.demanderPlaceDebout(p2);
		bus.demanderPlaceAssise(p3);
		bus.demanderPlaceDebout(p4);
		
		bus.demanderSortie(p1);
		bus.demanderSortie(p2);
		
		assert p1.estDehors() : "Le passager doit être sorti";
		assert p2.estDehors() : "Le passager doit être sorti";
	}
	
	void testAllerArretSuivant() {
		Autobus bus = new Autobus(2,2);
		FauxPassager p1 = new FauxPassager("p1",2);
		FauxPassager p2 = new FauxPassager("p2",2);
		bus.demanderPlaceAssise(p1);
		bus.demanderPlaceDebout(p2);
		//System.out.println("Les deux passagers doivent changer d'arrêt");
		bus.allerArretSuivant();
	}
	
	void testChangementPosition() {
		Autobus bus = new Autobus(2,1);
		FauxPassager p1 = new FauxPassager("p1",2);
		FauxPassager p2 = new FauxPassager("p2",2);
		bus.demanderPlaceAssise(p1);
		bus.demanderPlaceAssise(p2);
		//System.out.println("Le passager doit demander une place debout");
		bus.demanderChangerEnDebout(p1);
	//	System.out.println("Le passager doit demander une place assise");
		bus.demanderChangerEnAssis(p1);
	}

	void lancer() {
		int nbTest = 0;

		System.out.println('.'); nbTest++;
		testConstructeur();
		System.out.println('.'); nbTest++;
		testDemanderPlaceAssise();
		System.out.println('.'); nbTest++;
		testDemanderPlaceDebout();
		System.out.println('.'); nbTest++;
		testDemanderSortie();
		System.out.println('.'); nbTest++;
		testAllerArretSuivant();
		System.out.println('.'); nbTest++;
		testChangementPosition();
		
		System.out.println("(" + nbTest + "):OK: " + getClass().getName());
	}
	
	

}
