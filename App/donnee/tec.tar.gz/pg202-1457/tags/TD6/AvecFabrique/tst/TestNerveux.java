package tec;

class TestNerveux extends TestPassagerAbstrait {

    protected PassagerAbstrait creerPassager(String nom, int destination, Comportement comp) {
	return (PassagerAbstrait) new FauxComportementMontee(nom,destination,comp);
    }

    void testChoixChangerPlace() {
	Autobus b1 = new Autobus(1, 1);
	Comportement c1 = new Nerveux();
	PassagerAbstrait p1 = creerPassager("p1", 5, c1);
	b1.demanderPlaceAssise(p1);
	assert p1.estAssis();
	c1.choixChangerPlace(b1, 0, p1);
	assert p1.estDebout() == true : "b1 avait une place debout de libre, p1 change de position";
	b1.allerArretSuivant();
	// pas besoin d'appeler choixChangerPlace() 
	// car allerArretSuivant() appelle nouvelArret() 
	// dans PassagerAbstrait qui l'appelle ensuite sur p1
	assert p1.estAssis() == true : "b1 avait une place assise de libre, p1 change de position";

	Autobus b2 = new Autobus(1, 0);
	Comportement c2 = new Nerveux();
	PassagerAbstrait p2 = creerPassager("p2", 5, c2);
	b2.demanderPlaceAssise(p2);
	c2.choixChangerPlace(b2, 0, p2);
	assert p2.estAssis() == true : "b2 n'a plus de place debout, p2 reste immobile";

	Autobus b3 = new Autobus(0, 1);
	Comportement c3 = new Nerveux();
	PassagerAbstrait p3 = creerPassager("p3", 5, c3);
	b3.demanderPlaceDebout(p3);
	c3.choixChangerPlace(b3, 0, p3);
	assert p3.estDebout() == true : "b3 n'a plus de place assise, p3 reste immobile";
    }

    void testCodeConstant() {
	int nbTest = 0;
	
	nbTest++;
	testAccepterSortie();
	nbTest++;
	testAccepterPlaceDebout();
	nbTest++;
	testAccepterPlaceAssise();
	nbTest++;
	testAccesseurs();
    }
}