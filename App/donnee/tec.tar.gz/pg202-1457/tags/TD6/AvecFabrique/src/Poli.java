package tec;

class Poli implements Comportement {

/*
 * Laisse sa place assise si le le bus n’a plus de place assise
 */
    public void choixChangerPlace(Bus b, int arret, Passager p) {
	PassagerAbstrait pa = (PassagerAbstrait) p;
	Transport t = (Transport) b;
	
	if (t.aPlaceAssise() == false
	    && t.aPlaceDebout() == true)
	    b.demanderPlaceDebout(p);
    }
}