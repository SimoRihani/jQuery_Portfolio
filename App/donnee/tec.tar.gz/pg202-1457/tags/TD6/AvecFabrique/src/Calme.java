package tec;

class Calme implements Comportement {

/*
 * Ne bouge pas
 */
    public void choixChangerPlace(Bus b, int arret, Passager p) {
	PassagerAbstrait pa = (PassagerAbstrait) p;
    }
}