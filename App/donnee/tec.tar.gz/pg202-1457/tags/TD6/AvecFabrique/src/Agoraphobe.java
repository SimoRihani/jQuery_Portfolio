package tec;

class Agoraphobe implements Comportement {

/*
 * Sort si le bus est plein
 */
    public void choixChangerPlace(Bus b, int arret, Passager p) {
	PassagerAbstrait pa = (PassagerAbstrait) p;
	Transport t = (Transport) b;

	if (t.aPlaceAssise() == false
	    && t.aPlaceDebout() == false)
	    b.demanderSortie(p);
    }
}