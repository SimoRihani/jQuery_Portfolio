package tec;

public final class FabriqueTec {

/*
  Défini des constantes pour les différents comportement à la montée et à un nouvel arrêt
*/
    static final private int FATIGUE = 0;
    static final private int TETU = 1;
    static final private int REPOS = 2;
    static final private int SPORTIF = 3;

    static final private int CALME = 0;
    static final private int NERVEUX = 1;
    static final private int PRUDENT = 2;
    static final private int AGORAPHOBE = 3;
    static final private int POLI = 4;

/*
  Constructeurs pour les combinaisons de comportements //MODIFIER POUR RENVOYER DES USAGERS ET DELETE METHODE PASSAGER ET RENVOYER DIRECTEMENT ICI DANS FAIREPASSAGERSTANDARD
*/
    public static Passager fairePassagerStandard(String nom, int destination) {
	return fairePassager(nom, destination, REPOS, CALME);
    }
    public static Passager fairePassagerStresse(String nom, int destination) {
	return fairePassager(nom, destination, FATIGUE, PRUDENT);
    }
    public static Passager fairePassagerLunatique(String nom, int destination) {
	return fairePassager(nom, destination, SPORTIF, NERVEUX);
    }
    
/*
  Constructeurs pour les différents transports
*/
    public static Transport faireAutobus(int assis, int debout) {
	return new Autobus(assis, debout);
    }

/*
  Permet d'associer un comportement à la montée et un comportement à un nouvel arrêt
*/
    public static Passager fairePassager(String nom, int destination, int compArret, int compMontee) {
	Comportement c;

	// Choix du comportement à un nouvel arrêt
	switch (compArret) {
	case CALME : c = new Calme();
	case NERVEUX : c = new Nerveux();
	case PRUDENT : c = new Prudent();
	case AGORAPHOBE : c = new Agoraphobe();
	case POLI : c = new Poli();
	default : c = new Calme(); // pour qu'on ait une instanciation de c dans tous les cas
	}
	
	Passager p;
	// Choix du comportement à la montée
	switch (compMontee) {
	case FATIGUE : p = new Fatigue(nom, destination, c);
	case TETU : p = new Tetu(nom, destination, c);
	case REPOS : p = new Repos(nom, destination, c);
	case SPORTIF : p = new Sportif(nom, destination, c);
	default : p = new Fatigue(nom, destination, c); // idem
	}

	return p;
    }
    
}