package tec;

class Nerveux implements Comportement {

/*
 * Change de place à chaque arrêt
 */
    public void choixChangerPlace(Bus b, int arret, Passager p) {
	PassagerAbstrait pa = (PassagerAbstrait) p;
	Transport t = (Transport) b;

	if (p.estAssis() && t.aPlaceDebout())
	    b.demanderPlaceDebout(p);
	else if (p.estDebout() && t.aPlaceAssise())
	    b.demanderPlaceAssise(p);
    }
}